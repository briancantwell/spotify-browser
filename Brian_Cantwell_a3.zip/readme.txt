--Readme document for Brian Cantwell, cantwelb@uci.edu, 15306971--

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

*/10
- 1/1 Communicating with the webserver
- 1/1 Populating information about the user
- 3/3 Populating the search component
- 2/2 Artist page
- 1.5/1.5 Album page
- 1.5/1.5 Track page


2. How long, in hours, did it take you to complete this assignment?
30+, really I lost count.


3. What online resources did you consult when completing this assignment? (list specific URLs)
Theres more I'm sure but this is what I remembered to put down
https://developer.spotify.com/documentation/web-api/reference/#object-audiofeaturesobject
https://stackoverflow.com/questions/21428031/how-to-center-text-in-bootstrap-3-progress-bar/21428342
https://stackoverflow.com/questions/12937470/twitter-bootstrap-center-text-on-progress-bar
https://medium.com/@ingobrk/using-css-variables-in-angular-282a9edf1a20
https://angular.io/
https://www.w3schools.com


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
none


5. Did you add a bonus feature to your submission? If so, what is it and how should we see it?
no


6. Is there anything special we need to know in order to run your code?
no
